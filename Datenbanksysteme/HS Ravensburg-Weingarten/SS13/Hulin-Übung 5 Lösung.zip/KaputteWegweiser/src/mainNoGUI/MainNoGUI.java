package mainNoGUI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import work.Processing;

public class MainNoGUI {

	public static void main(String[] args) {
		boolean ok;
		String gemeindename = "";
	    InputStreamReader isr = new InputStreamReader(System.in);
	    BufferedReader br = new BufferedReader(isr);
	    Processing p = new Processing ();
		
		try {
			String dbserver = "neptun.fbe.fh-weingarten.de";
			String dbname = "namib";
			String user = "dabs_03";
			String pwd = "dabs_03";
			System.out.println("Defaultwerte �bernehmen? J/N ");
			String defaultJ = br.readLine();
			if (defaultJ.charAt(0) != 'J') {
				System.out.println("DB-Server?");
				dbserver = br.readLine();
				System.out.println("DB-Name?");
				dbname = br.readLine();
				System.out.println("User?");
				user = br.readLine();
				System.out.println("Passwort?");
				pwd = br.readLine();
			}
			p.anmeldung(dbserver, dbname, user, pwd);

			do {
				System.out.println();
				System.out.println("Gemeindename? (X f�r Abbruch) ");
				gemeindename = br.readLine();
				ok = p.holeGemeinde(gemeindename);
				if (ok) p.getGemeinde().druckeGemeinde();
				else System.out.println("Gemeinde mit diesem Namen existiert nicht.");
			} while (!(gemeindename.equals("") || gemeindename.equals("X")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			p.abmeldung();
		}
		
	}
}
