package work;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import schema.Gemeinde;
import schema.Hauptwegweiser;
import schema.Kommentar;
import schema.Standort;
import schema.Wegweiser;
import schema.Zwischenwegweiser;

public class Processing {
	private Gemeinde g = new Gemeinde ();
	private Connection conn;
	private PreparedStatement stmtStandorte;
	private PreparedStatement stmtWegweiser;
	private PreparedStatement stmtKommentare;
	private ResultSet rsw; // ResultSet f�r Wegweiser
	private ResultSet rsk; // ResultSet f�r Kommentare
		
	public Processing() {
	}

	public Gemeinde getGemeinde() {
		return g;
	}

	public boolean anmeldung (String server, String dbname, String user, String pwd) {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (ClassNotFoundException ex) {
			System.out.println("Fehler: " + ex.getMessage());
			ex.printStackTrace();
			System.exit(1);
		}
		
		try {
			String connstring = "jdbc:oracle:thin:@" + server + ":1521:" + dbname;
			conn = DriverManager.getConnection(connstring,user,pwd);
			String sqlstr = "SELECT Stid, Lagebeschreibung, Laenge, Breite ";
			sqlstr += "FROM Standort S, Gemeinde G ";
			sqlstr += "WHERE gname = ? AND G.Gid = S.Gemeinde ";
			sqlstr += "AND EXISTS (SELECT WID FROM Wegweiser W WHERE W.Standort = S.Stid AND (Zustand = 'fehlerhaft' OR Zustand = 'fehlt')) ";
			sqlstr += "ORDER BY S.stid";
			stmtStandorte = conn.prepareStatement(sqlstr);

			sqlstr = "SELECT WID, Typ, Zustand, Fernziel, Nahziel, kmfern, kmnah, Pfeilrichtung ";
			sqlstr += "FROM Wegweiser ";
			sqlstr += "WHERE Standort = ? AND (Zustand = 'fehlt' OR Zustand = 'fehlerhaft')";
			stmtWegweiser = conn.prepareStatement(sqlstr);
			
			sqlstr = "SELECT to_char(Datum, 'dd.mm.yyyy') as Datum, Text FROM Kommentar WHERE Standort = ?";
			stmtKommentare = conn.prepareStatement(sqlstr);
			return true;
		} catch (SQLException ex) {
			System.out.println("Fehler: " + ex.getMessage());
			ex.printStackTrace();
			System.exit(1);
		}
		return false;
	}
	
	public boolean holeGemeinde (String gemeindename) {
		try {
			Statement stmtGemeinde = conn.createStatement();
			ResultSet rs = stmtGemeinde.executeQuery("SELECT GID FROM Gemeinde WHERE GName = '" + gemeindename +"'");
			if (rs.next()) {
				g.reset();
				g.setGid(rs.getInt("GID"));
				g.setGname(gemeindename);
				// Hole alle Standorte der Gemeinde aus der Datenbank
				stmtStandorte.setString(1, gemeindename);
				rs = stmtStandorte.executeQuery();
				while (rs.next()){
					Standort s = new Standort (rs.getInt("Stid"),rs.getString("Lagebeschreibung"),rs.getFloat("Laenge"),rs.getFloat("Breite"));
					holeWegweiser (s); //Hole alle Wegweiser
					holeKommentare (s);
					g.addStandort(s);					
				}
				return true;
			} else return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public void holeWegweiser(Standort s) {
		try {
			stmtWegweiser.setInt(1, s.getStid());
			rsw = stmtWegweiser.executeQuery();
			while (rsw.next()) {
				Wegweiser w;
				if (rsw.getString("Typ").equals("Haupt")) 
					w = new Hauptwegweiser (rsw.getInt("WID"), rsw.getString("Zustand"), rsw.getString("Fernziel"), rsw.getString("Nahziel"), rsw.getFloat("kmfern"),rsw.getFloat("kmnah"));
				else w = new Zwischenwegweiser (rsw.getInt("WID"), rsw.getString("Zustand"),rsw.getString("Pfeilrichtung"));
				if (rsw.getString("Zustand").equals("fehlt")) s.addFehltWW(w);
				else s.addFehlerWW(w);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void holeKommentare (Standort s) {
		try {
			stmtKommentare.setInt(1, s.getStid());
			rsk = stmtKommentare.executeQuery();
			while (rsk.next()) {
				Kommentar k = new Kommentar (rsk.getString("Datum"), rsk.getString("Text"));
				s.addKommentar(k);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void abmeldung () {
		try {
			stmtStandorte.close();
			stmtWegweiser.close();
			stmtKommentare.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
