package schema;

public class Zwischenwegweiser extends Wegweiser {
	private String pfeilrichtung;

	public Zwischenwegweiser(int wid, String zustand, String pfeilrichtung) {
		super(wid, zustand);
		this.pfeilrichtung = pfeilrichtung;
	}
	
	public void druckeWegweiser () {
		System.out.format("\tZwischenwegweiser %s\n\n", pfeilrichtung);
	}
}
