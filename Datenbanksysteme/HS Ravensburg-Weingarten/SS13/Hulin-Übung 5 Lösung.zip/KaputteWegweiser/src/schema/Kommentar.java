package schema;

public class Kommentar {
	private String datum;
	private String text;
	
	public Kommentar(String datum, String text) {
		this.datum = datum;
		this.text = text;
	}

	public String getDatum() {
		return datum;
	}
	public String getText() {
		return text;
	}
	
	public void druckeKommentar () {
		System.out.format("\t%s %.80s\n",datum,text);
	}

}
