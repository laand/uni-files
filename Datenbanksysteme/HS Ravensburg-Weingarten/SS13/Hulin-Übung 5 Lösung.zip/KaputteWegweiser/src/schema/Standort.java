package schema;

import java.util.ArrayList;

public class Standort {
	private int stid;
	private String lagebeschreibung;
	private float laenge;
	private float breite;
	private ArrayList <Wegweiser> fehltWW;
	private ArrayList <Wegweiser> fehlerWW;
	private ArrayList <Kommentar> kommentare;

	public Standort(int stid, String lagebeschreibung, float laenge,
			float breite) {
		this.stid = stid;
		this.lagebeschreibung = lagebeschreibung;
		this.laenge = laenge;
		this.breite = breite;
		this.fehltWW = new ArrayList <Wegweiser> ();
		this.fehlerWW = new ArrayList <Wegweiser> ();
		this.kommentare = new ArrayList <Kommentar> ();
	}
	
	public int getStid () {
		return this.stid;
	}
	
	public void addFehltWW(Wegweiser w) {
		fehltWW.add(w);
	}
	
	public void addFehlerWW(Wegweiser w) {
		fehlerWW.add(w);
	}
	
	public void addKommentar(Kommentar k) {
		kommentare.add(k);
	}

	public void druckeStandort () {
		System.out.format("Standort Nr. %d am Punkt (%.5f, %.5f)\n",stid,laenge,breite);
		System.out.format("Lagebeschreibung: %s\n\n", lagebeschreibung);
		
		// drucke fehlende Wegweiser
		if (this.fehltWW.isEmpty()) System.out.format("  Fehlende Wegweiser: keine\n\n");
		else {
			System.out.format("  Fehlende Wegweiser: \n");
			for (int i = 0; i < this.fehltWW.size(); i++) {
				Wegweiser w = this.fehltWW.get(i);
				w.druckeWegweiser ();
			}
		}
		// drucke fehlerhafte Wegweiser
		if (this.fehlerWW.isEmpty()) System.out.format("  Fehlerhafte Wegweiser: keine\n\n");
		else {
			System.out.format("  Fehlerhafte Wegweiser: \n");
			for (int i = 0; i < this.fehlerWW.size(); i++) {
				Wegweiser w = this.fehlerWW.get(i);
				w.druckeWegweiser ();
			}
		}
		// drucke Kommentare
		if (!this.kommentare.isEmpty()) {
			System.out.format("  Kommentare: \n");
			for (int i = 0; i < this.kommentare.size(); i++) {
				Kommentar k = this.kommentare.get(i);
				k.druckeKommentar ();
			}
		}		
	}

}
