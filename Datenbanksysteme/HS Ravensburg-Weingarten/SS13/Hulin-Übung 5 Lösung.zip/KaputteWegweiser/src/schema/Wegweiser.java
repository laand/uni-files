package schema;

public class Wegweiser {
	protected int wid;
	protected String zustand;

	public Wegweiser(int wid, String zustand) {
		this.wid = wid;
		this.zustand = zustand;
	}
	
	public void druckeWegweiser () {
		
	}
}
