package schema;

public class Hauptwegweiser extends Wegweiser {
	private String fernziel;
	private String nahziel;
	private float kmfern;
	private float kmnah;

	public Hauptwegweiser(int wid, String zustand, String fernziel, String nahziel, float kmfern,
			float kmnah) {
		super(wid, zustand);
		this.fernziel = fernziel;
		this.nahziel = nahziel;
		this.kmfern = kmfern;
		this.kmnah = kmnah;
	}

	public void druckeWegweiser () {
	    if (this.kmfern < 10.0) System.out.format("\t%-20.20s  %.1f\n", fernziel, kmfern);
	    else  System.out.format("\t%-20.20s  %.0f\n", fernziel, kmfern);
	    if (kmnah < 10.0) System.out.format("\t%-20.20s  %.1f\n\n", nahziel, kmnah);
	    else System.out.format("\t%-20.20s  %.0f\n\n", nahziel, kmnah);
	}
}
