package schema;

import java.util.ArrayList;

public class Gemeinde {
	private int gid;
	private String gname;
	private ArrayList <Standort> standorte;

	public Gemeinde() {
		standorte = new ArrayList <Standort> ();
	}
	
	public void reset () {
		this.gid = -1;
		this.gname = "";
		standorte.clear();
	}
	
	public void setGid(int gid) {
		this.gid = gid;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public int getGid() {
		return gid;
	}
	public String getGname() {
		return gname;
	}
	public ArrayList<Standort> getStandorte() {
		return standorte;
	}

	public void addStandort (Standort s) {
		standorte.add(s);
	}

	public void druckeGemeinde () {
		
		// Drucke Ueberschrift
		System.out.format("Standorte mit fehlerhaften oder fehlenden Wegweisern in der Gemeinde %s\n\n", this.gname);
		 
		// Standorte drucken
		 for (int i = 0; i < this.standorte.size(); i++) {
		   Standort s = this.standorte.get(i);
		   s.druckeStandort();
		 }
	}
	
}
